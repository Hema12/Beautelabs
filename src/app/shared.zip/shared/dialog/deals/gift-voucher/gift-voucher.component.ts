import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gift-voucher',
  templateUrl: './gift-voucher.component.html',
  styleUrls: ['./gift-voucher.component.scss']
})
export class GiftVoucherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
