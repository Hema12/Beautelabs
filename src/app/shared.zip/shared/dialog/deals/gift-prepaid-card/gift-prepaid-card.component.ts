import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gift-prepaid-card',
  templateUrl: './gift-prepaid-card.component.html',
  styleUrls: ['./gift-prepaid-card.component.scss']
})
export class GiftPrepaidCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
