import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loyalty-points',
  templateUrl: './loyalty-points.component.html',
  styleUrls: ['./loyalty-points.component.scss']
})
export class LoyaltyPointsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
