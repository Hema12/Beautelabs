import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sale-view',
  templateUrl: './sale-view.component.html',
  styleUrls: ['./sale-view.component.scss']
})
export class SaleViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
