import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-expense-create',
  templateUrl: './expense-create.component.html',
  styleUrls: ['./expense-create.component.scss']
})
export class ExpenseCreateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
