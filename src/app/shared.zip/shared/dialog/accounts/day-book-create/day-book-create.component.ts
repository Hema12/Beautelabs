import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-day-book-create',
  templateUrl: './day-book-create.component.html',
  styleUrls: ['./day-book-create.component.scss']
})
export class DayBookCreateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
