import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sale-bill-create',
  templateUrl: './sale-bill-create.component.html',
  styleUrls: ['./sale-bill-create.component.scss']
})
export class SaleBillCreateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
