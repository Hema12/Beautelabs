import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bank-cash-register',
  templateUrl: './bank-cash-register.component.html',
  styleUrls: ['./bank-cash-register.component.scss']
})
export class BankCashRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
