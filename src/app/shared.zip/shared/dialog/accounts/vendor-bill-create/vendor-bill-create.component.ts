import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendor-bill-create',
  templateUrl: './vendor-bill-create.component.html',
  styleUrls: ['./vendor-bill-create.component.scss']
})
export class VendorBillCreateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
