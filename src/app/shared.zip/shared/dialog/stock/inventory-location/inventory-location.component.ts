import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inventory-location',
  templateUrl: './inventory-location.component.html',
  styleUrls: ['./inventory-location.component.scss']
})
export class InventoryLocationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
