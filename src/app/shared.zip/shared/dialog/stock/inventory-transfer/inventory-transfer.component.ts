import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inventory-transfer',
  templateUrl: './inventory-transfer.component.html',
  styleUrls: ['./inventory-transfer.component.scss']
})
export class InventoryTransferComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
