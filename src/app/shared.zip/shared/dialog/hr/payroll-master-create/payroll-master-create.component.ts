import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payroll-master-create',
  templateUrl: './payroll-master-create.component.html',
  styleUrls: ['./payroll-master-create.component.scss']
})
export class PayrollMasterCreateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
