import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-user',
  templateUrl: './shop-user.component.html',
  styleUrls: ['./shop-user.component.scss']
})
export class ShopUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
