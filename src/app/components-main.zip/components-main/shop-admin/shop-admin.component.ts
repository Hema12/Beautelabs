import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-admin',
  templateUrl: './shop-admin.component.html',
  styleUrls: ['./shop-admin.component.scss']
})
export class ShopAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
