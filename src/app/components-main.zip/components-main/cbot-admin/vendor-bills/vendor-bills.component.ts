import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendor-bills',
  templateUrl: './vendor-bills.component.html',
  styleUrls: ['./vendor-bills.component.scss']
})
export class VendorBillsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
