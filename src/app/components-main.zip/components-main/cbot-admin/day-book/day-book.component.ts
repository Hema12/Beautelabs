import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-day-book',
  templateUrl: './day-book.component.html',
  styleUrls: ['./day-book.component.scss']
})
export class DayBookComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
