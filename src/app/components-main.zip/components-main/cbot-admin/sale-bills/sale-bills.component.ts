import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sale-bills',
  templateUrl: './sale-bills.component.html',
  styleUrls: ['./sale-bills.component.scss']
})
export class SaleBillsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
