import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prepaid-card',
  templateUrl: './prepaid-card.component.html',
  styleUrls: ['./prepaid-card.component.scss']
})
export class PrepaidCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
