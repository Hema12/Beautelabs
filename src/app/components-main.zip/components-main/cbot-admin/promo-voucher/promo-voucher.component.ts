import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-promo-voucher',
  templateUrl: './promo-voucher.component.html',
  styleUrls: ['./promo-voucher.component.scss']
})
export class PromoVoucherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
