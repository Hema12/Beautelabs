import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cbot-admin',
  templateUrl: './cbot-admin.component.html',
  styleUrls: ['./cbot-admin.component.scss']
})
export class CbotAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
